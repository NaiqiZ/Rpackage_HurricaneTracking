
#' Storm tracks and information from 1851 to 2022
#'
#' A dataset with information about datetime, longitude, latitude, landfall situation, maximum sustained wind, minimum pressure, wind radii maximum extent(in nautical miles) in the northeastern, southeastern, southwestern, and northwestern quadrants of the 34, 50, 64 kt winds, and the radius of maximum wind of the 53972 observed storms from 1851 to 2022
#'
#' @format a dataframe with 53972 rows and 23 columns
#' \describe{
#'     \item{ID}{date of the storm}
#'     \item{Name}{name of the storm}
#'     \item{Date}{date of the storm observation}
#'     \item{Time}{time of the storm observation}
#'     \item{Landfall}{landfall situation of the storm}
#'     \item{Status_of_system}{status.of system of the storm}
#'     \item{Latitude}{latitude of the storm, in decimal degrees north}
#'     \item{Longitude}{longitude of the storm, in decimal degrees east}
#'     \item{Maximum_sustained_wind}{maximum sustained wind of the storm}
#'     \item{Minimum_Pressure}{minimum pressure of the storm}
#'     \item{kt34_northeastern_quadrant}{the 34kt wind radii maximum extent(in nautical miles) of the storm in northeastern quadrant}
#'     \item{kt34_southeastern_quadrant}{the 34kt wind radii maximum extent(in nautical miles) of the storm in southeastern quadrant}
#'     \item{kt34_southwestern_quadrant}{the 34kt wind radii maximum extent(in nautical miles) of the storm in southwestern quadrant}
#'     \item{kt34_northwestern_quadrant}{the 34kt wind radii maximum extent(in nautical miles) of the storm in northwestern quadrant}
#'     \item{kt50_northeastern_quadrant}{the 50kt wind radii maximum extent(in nautical miles) of the storm in northeastern quadrant}
#'     \item{kt50_southeastern_quadrant}{the 50kt wind radii maximum extent(in nautical miles) of the storm in southeastern quadrant}
#'     \item{kt50_southwestern_quadrant}{the 50kt wind radii maximum extent(in nautical miles) of the storm in southwestern quadrant}
#'     \item{kt50_northwestern_quadrant}{the 50kt wind radii maximum extent(in nautical miles) of the storm in northwestern quadrant}
#'     \item{kt64_northeastern_quadrant}{the 64kt wind radii maximum extent(in nautical miles) of the storm in northeastern quadrant}
#'     \item{kt64_southeastern_quadrant}{the 64kt wind radii maximum extent(in nautical miles) of the storm in southeastern quadrant}
#'     \item{kt64_southwestern_quadrant}{the 64kt wind radii maximum extent(in nautical miles) of the storm in southwestern quadrant}
#'     \item{kt64_northwestern_quadrant}{the 64kt wind radii maximum extent(in nautical miles) of the storm in northwestern quadrant}
#'     \item{Radius_Maximum_Wind}{the radius of Maximum Wind of the storm}
#' }
"dat"
